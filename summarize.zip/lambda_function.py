import io
import re
import time
import urllib.parse
from collections import Counter
from xml.sax.saxutils import escape

import boto3
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

s3 = boto3.client("s3")
textract = boto3.client("textract")
comprehend = boto3.client("comprehend")

STOP_WORDS = set(
    "the a an and or of to in is are was were be been for on with as by that this it at "
    "from which have has had not but they their can will also its these those such than".split()
)


def extract_text(bucket, key):
    job = textract.start_document_text_detection(
        DocumentLocation={"S3Object": {"Bucket": bucket, "Name": key}}
    )
    job_id = job["JobId"]
    while True:
        res = textract.get_document_text_detection(JobId=job_id)
        status = res["JobStatus"]
        if status in ("SUCCEEDED", "FAILED"):
            break
        time.sleep(3)
    if status == "FAILED":
        raise RuntimeError("Textract job failed")

    lines, token = [], None
    while True:
        kwargs = {"JobId": job_id}
        if token:
            kwargs["NextToken"] = token
        res = textract.get_document_text_detection(**kwargs)
        lines += [b["Text"] for b in res["Blocks"] if b["BlockType"] == "LINE"]
        token = res.get("NextToken")
        if not token:
            break
    return " ".join(lines)


def get_key_phrases(text, limit=10):
    chunk = text.encode("utf-8")[:50000].decode("utf-8", "ignore")
    res = comprehend.detect_key_phrases(Text=chunk, LanguageCode="en")
    seen, phrases = set(), []
    for p in sorted(res["KeyPhrases"], key=lambda x: -x["Score"]):
        t = p["Text"].strip()
        if t.lower() not in seen and len(t) > 3:
            seen.add(t.lower())
            phrases.append(t)
        if len(phrases) == limit:
            break
    return phrases


def summarize(text, n_sentences=6):
    sentences = re.split(r"(?<=[.!?])\s+", text)
    words = re.findall(r"[a-z']+", text.lower())
    freq = Counter(w for w in words if w not in STOP_WORDS and len(w) > 2)

    scored = []
    for i, s in enumerate(sentences):
        tokens = re.findall(r"[a-z']+", s.lower())
        if len(tokens) < 6:
            continue
        score = sum(freq[t] for t in tokens) / len(tokens)
        scored.append((score, i, s))

    top = sorted(scored, reverse=True)[:n_sentences]
    top.sort(key=lambda x: x[1])
    return " ".join(s for _, _, s in top) or text[:1000]


def build_pdf(title, summary, phrases):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(escape(f"Summary of {title}"), styles["Title"]),
        Spacer(1, 12),
        Paragraph("Summary", styles["Heading2"]),
        Paragraph(escape(summary), styles["BodyText"]),
        Spacer(1, 12),
        Paragraph("Key Phrases (Amazon Comprehend)", styles["Heading2"]),
    ]
    for p in phrases:
        story.append(Paragraph("&bull; " + escape(p), styles["BodyText"]))
    doc.build(story)
    return buf.getvalue()


def lambda_handler(event, context):
    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])
        print(f"Processing s3://{bucket}/{key}")

        text = extract_text(bucket, key)
        if not text.strip():
            print("No text found in PDF")
            continue

        phrases = get_key_phrases(text)
        summary = summarize(text)

        name = key.split("/")[-1].rsplit(".", 1)[0]
        pdf_bytes = build_pdf(name, summary, phrases)

        out_key = f"output/{name}_summary.pdf"
        s3.put_object(Bucket=bucket, Key=out_key, Body=pdf_bytes, ContentType="application/pdf")
        print(f"Saved s3://{bucket}/{out_key}")
    return {"status": "done"}